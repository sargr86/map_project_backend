<div class="div_404">
   <!-- <div class="text_div">
        <h3>PAGE NOT FOUND</h3>
        <hr><br>
        <p>
            The page you are trying to find is either removed or relocated. We are sorry <br>
            for the inconvenience.
        </p>
    </div>-->
    <div class="img_div">
        <img src="<?php echo base_url('assets/images/page_404.png'); ?>">
    </div>
    <br class="clear">
</div>
