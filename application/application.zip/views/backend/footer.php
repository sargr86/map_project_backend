<div>
    <script src="<?php echo base_url();?>assets/js/backend/bottom.main.js"></script>
</div>