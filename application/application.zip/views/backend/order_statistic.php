
<div class="order_statistic_main_1">
    <input type="text" name="date_statistic" class="date_statistic">
    <button class="search_statistic">Search</button>
</div>
<div class="order_statistic_main">

</div>
<script src="<?php echo base_url();?>assets/js/chart.js"></script>