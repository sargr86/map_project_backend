<table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;padding:20px;background:#fff;">
    <tr>
        <td style="font-family:sans-serif;font-size:13px;vertical-align:top;">
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:orange;">Updated login email successfully</p>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:#3e3e3e;">Dear <?php echo $first_name. ' '. $last_name; ?>:</p>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:#3e3e3e;">You have successfully updated your login email. The new email address is: <span style="color: #0d8ee9;"><?php echo $email; ?></span></p>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:#3e3e3e;">We will send all future emails to your new email address. </p>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:#3e3e3e;">If you have any questions, please feel free to chat with us online, or send an email to <a href="<?php echo base_url(); ?>">cs@luggagetoship.com.</a></p>
            <br>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:#3e3e3e;">Sincerely,</p>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:#3e3e3e;">Luggage To Ship Customer Service Team</p>
        </td>
    </tr>
</table>
