<table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;padding:20px;background:#fff;">
    <tr>
        <td style="font-family:sans-serif;font-size:13px;vertical-align:top;">
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;margin-bottom:30px;font-weight:600;color:#ff9107">Reset Password Successfully</p>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:#3e3e3e;">Dear <?php echo $first_name. ' '. $last_name; ?>:</p>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:#3e3e3e;">You have successfully changed your Luggage To Ship password.</p>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:#3e3e3e;">Please always keep your login information secure and confidential.</p>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:#3e3e3e;">If you have any questions, please feel free to chat with us online, or send an email to <a href="#">cs@luggagetoship.com.</a> </p>
            <br>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:5px;color:#3e3e3e;">Sincerely,</p>
            <p style="font-family:sans-serif;font-size:13px;font-weight:normal;margin:0;Margin-bottom:15px;color:#3e3e3e;">Luggage To Ship Customer Service Team</p>
        </td>
    </tr>
</table>

<!--<ul style="background: white;margin: 0">
    <li style="list-style: none;">Tips:</li>
    <li style="list-style: none;">
        <ul>
            <li style="list-style: disc;">How to update the login email</li>
            <li style="list-style: disc;">How to pack items</li>
            <li style="list-style: disc;">How to submit an order</li>
        </ul>
    </li>
    <li style="list-style: none;">Tools:</li>
    <li style="list-style: none;">
        <ul>
            <li style="list-style: disc;">Luggage size and weight calculator</li>
            <li style="list-style: disc;">Drop-off locator</li>
            <li style="list-style: disc;">Price calculator</li>
        </ul>
    </li>
</ul>-->