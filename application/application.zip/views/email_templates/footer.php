<div class="footer" style="clear:both;padding-top:0px;text-align:center;width:100%;border-top: 1px solid;">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;padding-bottom:20px;background-color:#fff;">

       <!-- <tr>
            <td>
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td style="padding-bottom:7px;padding-top:5px;border-bottom:1px solid #eaeaea;">
                            <ul style="list-style:none;padding:0;margin-bottom:0;text-align:center">
                                <li style="display: inline-block;font-style:italic;font-size:20px;color: #252525;vertical-align: middle;margin-right:10px;">Stay in touch</li>
                                <li style="display: inline-block;vertical-align: middle;"><a href=""><img src="<?php /*echo $twitter_image; */?>" style="margin-right:10px"></a></li>
                                <li style="display: inline-block;vertical-align: middle;"><a href=""><img src="<?php /*echo $fb_image; */?>" style="margin-right:10px"></a></li>
                                <li style="display: inline-block;vertical-align: middle;"><a href=""><img src="<?php /*echo $google_image; */?>" style="margin-right:10px"></a></li>
                                <li style="display: inline-block;vertical-align: middle;"><a href=""><img src="<?php /*echo $pinterest_image;*/?>" style="margin-right:10px"></a></li>
                            </ul>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>-->

        <tr>
            <td class="content-block" style="padding-top: 20px;color:#999999;font-size:12px;text-align: center;">
                <a href="<?php echo base_url('luggagetoship-privacy-policy')?>" style="text-decoration:none;font-family:sans-serif;font-size:14px;color:#999999;font-size:12px;">Privacy Policy</a> | <a href="<?php echo base_url('luggagetoship-terms-of-use')?>" style="text-decoration:none;font-family:sans-serif;font-size:14px;color:#999999;font-size:12px;">Terms and Conditions</a>
            </td>
        </tr>
        <tr>
            <td class="content-block" style="font-family:sans-serif;font-size:14px;vertical-align:top;color:#999999;font-size:12px;text-align:center;">
                288 East 45th street, Ground Floor, New York, NY 10017
            </td>
        </tr>
        <tr>
            <td class="content-block powered-by" style="font-family:sans-serif;font-size:14px;vertical-align:top;color:#999999;font-size:12px;text-align:center;">
                © Copyright <?php echo date('Y');?> LuggageToShip All Right Reserved.
            </td>
        </tr>
    </table>
</div>
