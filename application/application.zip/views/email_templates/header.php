
<?php
if(!empty($subject_description)){ ?>
    <div style="display:none;font-size:1px;color:#333333;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;">
        <?php echo $subject_description; ?>
    </div>
<?php } ?>
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;border-bottom:4px solid #0d8ee9; background:#fff;">
    <tbody>
    <tr>
        <td align="center" valign="top" >
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;">
                <tr>
                    <td align="center" valign="top">
                       <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;">
                            <tr>
                                <td align="left" style="padding:15px 20px;text-align: center;" >
                                    <img style="width: 150px" src="<?php echo base_url('assets/images/logo.png'); ?>">
                                </td>
                               <!-- <td align="right" style="padding:10px 20px;" class="min-width-40">
                                    <table border="0" cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td style="padding-bottom:7px;">
                                                <img src="<?php /*echo $phone_image; */?>" style="float:left;margin-right:10px"><a style="float:left;text-decoration:none;color:#0d8ee9;font-size:13px;margin-top: 7px;font-family: sans-serif;">1800 678 6167</a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="<?php /*echo $mail_image; */?>" style="float:left;margin-right:10px"><a href="mailto:cs@luggagetoship.com" style="float:left;text-decoration:none;color:#0d8ee9;font-size:13px;margin-top: 7px;font-family: sans-serif;">Luggage To Ship</a>
                                            </td>
                                        </tr>
                                    </table>
                                </td>-->
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>

    <tr>
        <td align="center" valign="top">
<!--            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;background-color:#0d8ee9;">
                <tr>
                    <td align="center">
                        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;width:100%;">
                            <tr>
                                <td align="center" >
                                    <a href="<?php /*echo base_url('shipping-rates'); */?>" style="font-family: sans-serif;text-decoration:none;display:block;font-size:13px;padding: 13px;color: #fff;">SHIPPING RATE</a>
                                </td>
                                <td align="center" >
                                    <a href="<?php /*echo base_url('luggage-storage-services')*/?>" style="font-family: sans-serif;text-decoration:none;display:block;font-size:13px;padding: 13px;color: #fff;">STORAGE SERVICES</a>
                                </td>
                                <td align="center" >
                                    <a href="<?php /*echo base_url('luggage-and-question')*/?>" style="font-family: sans-serif;text-decoration:none;display:block;font-size:13px;padding: 13px;color: #fff;">FAQ</a>
                                </td>
                            </tr>
                        </table>
                    </td>

                    <td align="center" valign="top" width="31%" style="background-color: #ff9107; vertical-align: middle;">
                        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;background-color:#ff9107;">
                            <tr>
                                <td align="right" >
                                    <a href="<?php /*echo base_url('login')*/?>" style="text-decoration:none;display:block;font-size: 13px;padding: 5px;line-height:1;color: #fff;border:1px solid #ffc276;width:55px;margin:10px;border-radius:4px;text-align:center;margin-right:30px;">LOGIN</a>
                                </td>
                        </table>
                    </td>
                </tr>
            </table>-->
        </td>
    </tr>

    </tbody>
</table>
