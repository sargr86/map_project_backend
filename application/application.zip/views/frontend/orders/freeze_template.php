<div id="freeze_div">
    <h4>Sorry!</h4>
    <p>
    You can not edit it.<br>
    The administrator is currently working on this order.<br>
    This will take approximately <b><?php echo $minutes; ?></b><br>
    </p>
</div>
