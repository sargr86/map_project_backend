<div>
    <p style="padding: 20px;text-align: center;">The label link is expired. Please call <span class="blue-color">1-800-678-6167</span> if you have any question. Thank you!</p>
</div>